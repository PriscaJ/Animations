package cs3500.animator.controller;

import org.junit.Before;
import org.junit.Test;

import java.awt.event.ActionEvent;


public class ControllerTest {

  @Before
  public void initData() {

  }

  @Test
  public void testActionPerformed() {
    ActionEvent e = new ActionEvent();
  }


}
